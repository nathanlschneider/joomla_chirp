<?php

/**
 * Plugin installer class
 * @copyright 2023 Quirkable
 * @license GPL 2.0+
 * @since 1.0.0
 */
class PlgSystemChirpInstallerScript
{
	/**
	 * Called on installation
	 *
	 * @param   InstallerAdapter $adapter - The object responsible for running this script
	 * @return boolean
	 */
	public function install(InstallerAdapter $adapter)
	{
		// Enable plugin
		$db  = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->update('#__extensions');
		$query->set($db->quoteName('enabled') . ' = 1');
		$query->set($db->quoteName('protected') . ' = 1');
		$query->where($db->quoteName('name') . ' = ' . $db->quote('plg_system_chirp'));
		$query->where($db->quoteName('type') . ' = ' . $db->quote('plugin'));
		$db->setQuery($query);
		$result = $db->execute();

		return $result;
	}
}

