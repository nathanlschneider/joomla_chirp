DROP TABLE IF EXISTS `#__chirp_products`;
DROP TABLE IF EXISTS `#__chirp_names`;
DROP TABLE IF EXISTS `#__chirp_control`;
