DROP TABLE IF EXISTS `#__chirp_control`;
DROP TABLE IF EXISTS `#__chirp_order_ref`;
