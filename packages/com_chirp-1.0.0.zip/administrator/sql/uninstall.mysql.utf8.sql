DROP TABLE IF EXISTS `#__chirp_dummy_products`;
