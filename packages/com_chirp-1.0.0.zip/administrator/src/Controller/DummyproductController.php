<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Chirp
 * @author     Nathan Schneider <nathan@quirkable.io>
 * @copyright  2023 Quirkable
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Chirp\Component\Chirp\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/**
 * Dummyproduct controller class.
 *
 * @since  1.0.0
 */
class DummyproductController extends FormController
{
	protected $view_list = 'dummyproducts';
}
