// (c) 2023 Quirkable. All Rights Reserved.
// https://quirkable.io/

(function () {
    window.addEventListener("DOMContentLoaded", function () {
        console.log("loaded");
        const body = document.querySelector("body");

        if (!body.classList.contains("admin")) {
            const div = document.createElement("div");
            div.id = "chirp_nest";
            body.appendChild(div);
        }
    });

    /**
     *  options object - Fetch options
     */
    const options = {};

    /**
     * chirp function - fetches chirp from Joomla and inserts it into the DOM
     */
    async function chirp() {
        const chirpNest = document.querySelector("#chirp_nest");
        const fetched = await fetch(
            "/index.php?option=com_chirp&task=api.getName",
            options
        );
        const json = await fetched.json();
        console.log(json);
    }

    /**
     *  timerTrigger function - returns a random integer for the chirp timer
     */
    function randoMinMax(min, max) {
        return min + Math.random() * (max - min);
    }

    for (i = 0; i < 5; i++) {
        (function (i) {
            setTimeout(function () {
                console.log(i);
            }, Math.floor(Math.random() * 1000));
        })(i); //Pass current value into self-executing anonymous function
    }
})();
