DROP TABLE IF EXISTS `#__chirp_products`;
